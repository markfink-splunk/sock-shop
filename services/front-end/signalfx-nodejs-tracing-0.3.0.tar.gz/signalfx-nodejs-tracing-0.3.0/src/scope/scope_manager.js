'use strict'

const ScopeManager = require('./noop/scope_manager')

module.exports = ScopeManager
