/* eslint-disable */
// file mostly untouched from apollo-graphql

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var signature_1 = require("./signature");
exports.defaultEngineReportingSignature = signature_1.defaultEngineReportingSignature;
