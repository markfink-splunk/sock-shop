'use strict'

const TextMapPropagator = require('./text_map')

class HttpPropagator extends TextMapPropagator {}

module.exports = HttpPropagator
