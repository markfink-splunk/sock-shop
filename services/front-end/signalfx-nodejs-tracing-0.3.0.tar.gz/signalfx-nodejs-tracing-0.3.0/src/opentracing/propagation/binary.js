'use strict'

class BinaryPropagator {
  inject (spanContext, carrier) {}

  extract (carrier) {
    return null
  }
}

module.exports = BinaryPropagator
