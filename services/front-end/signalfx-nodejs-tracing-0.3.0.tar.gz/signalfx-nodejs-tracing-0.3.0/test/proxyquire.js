'use strict'

module.exports = require('proxyquire')
