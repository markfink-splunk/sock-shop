'use strict'

const foo = require('./module')

module.exports = foo()
