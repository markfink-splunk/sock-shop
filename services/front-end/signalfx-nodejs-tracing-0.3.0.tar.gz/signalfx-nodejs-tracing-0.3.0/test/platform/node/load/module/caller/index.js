'use strict'

const platform = require('../../../../../../src/platform/node')

module.exports = () => platform.service()
