Examples for several supported libraries are available in the
[tracing-examples](https://github.com/signalfx/tracing-examples/tree/master/signalfx-tracing/signalfx-nodejs-tracing) GitHub repository.
