'use strict'

module.exports = {
  HTTP: 'http',
  WEB: 'web'
}
