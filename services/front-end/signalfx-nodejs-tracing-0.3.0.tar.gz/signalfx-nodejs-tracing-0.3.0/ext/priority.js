'use strict'

module.exports = {
  USER_REJECT: -1,
  AUTO_REJECT: 0,
  AUTO_KEEP: 1,
  USER_KEEP: 2
}
