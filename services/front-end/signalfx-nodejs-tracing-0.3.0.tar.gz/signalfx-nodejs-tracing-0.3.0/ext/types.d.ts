declare const types: {
  HTTP: 'http'
  WEB: 'web'
}

export = types
