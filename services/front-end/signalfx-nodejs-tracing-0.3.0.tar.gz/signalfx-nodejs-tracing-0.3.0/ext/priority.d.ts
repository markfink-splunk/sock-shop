declare const priority: {
  USER_REJECT: -1
  AUTO_REJECT: 0
  AUTO_KEEP: 1
  USER_KEEP: 2
}

export = priority
