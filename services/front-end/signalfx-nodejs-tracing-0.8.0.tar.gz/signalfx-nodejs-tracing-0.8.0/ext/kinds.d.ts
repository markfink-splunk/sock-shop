declare const kinds: {
  SERVER: 'server'
  CLIENT: 'client'
  PRODUCER: 'producer'
  CONSUMER: 'consumer'
}

export = kinds
