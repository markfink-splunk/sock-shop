'use strict'

module.exports = name => process.env[name]
