'use strict'

module.exports = require('async_hooks')
