'use strict'

const caller = require('./caller')

module.exports = () => caller()
