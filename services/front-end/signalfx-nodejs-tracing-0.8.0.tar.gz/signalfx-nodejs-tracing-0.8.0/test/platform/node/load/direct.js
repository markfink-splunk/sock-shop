'use strict'

const caller = require('./module/caller')

module.exports = caller()
