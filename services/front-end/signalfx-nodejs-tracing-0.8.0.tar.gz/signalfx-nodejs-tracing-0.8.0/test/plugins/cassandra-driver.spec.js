'use strict'

const semver = require('semver')
const agent = require('./agent')
const plugin = require('../../src/plugins/cassandra-driver')

wrapIt()

describe('Plugin', () => {
  let cassandra
  let tracer

  describe('cassandra-driver', () => {
    withVersions(plugin, 'cassandra-driver', version => {
      beforeEach(() => {
        tracer = require('../..')
        global.tracer = tracer
      })

      describe('without configuration', () => {
        let client

        before(() => {
          return agent.load(plugin, 'cassandra-driver')
        })

        after(() => {
          return agent.close()
        })

        beforeEach(done => {
          cassandra = require(`../../versions/cassandra-driver@${version}`).get()

          client = new cassandra.Client({
            contactPoints: ['127.0.0.1'],
            localDataCenter: 'datacenter1',
            keyspace: 'system'
          })

          client.connect(done)
        })

        afterEach(done => {
          client.shutdown(done)
        })

        it('should do automatic instrumentation', done => {
          const query = 'SELECT now() FROM local;'

          agent
            .use(traces => {
              expect(traces[0][0]).to.have.property('service', 'test')
              expect(traces[0][0]).to.have.property('name', 'SELECT')
              expect(traces[0][0].meta).to.have.property('db.type', 'cassandra')
              expect(traces[0][0].meta).to.have.property('span.kind', 'client')
              expect(traces[0][0].meta).to.have.property('peer.ipv4', '127.0.0.1')
              expect(traces[0][0].meta).to.have.property('peer.port', '9042')
              expect(traces[0][0].meta).to.have.property('db.statement', query)
              expect(traces[0][0].meta).to.have.property('db.instance', 'system')
            })
            .then(done)
            .catch(done)

          client.execute(query, err => err && done(err))
        })

        it('should support batch queries', done => {
          const id = '1234'
          const queries = [
            { query: 'INSERT INTO test.test (id) VALUES (?)', params: [id] },
            `UPDATE test.test SET test='test' WHERE id='${id}';`
          ]

          agent
            .use(traces => {
              expect(traces[0][0]).to.have.property('name', 'Batch: INSERT;UPDATE')
            })
            .then(done)
            .catch(done)

          client.batch(queries, { prepare: true }, err => err && done(err))
        })

        it('should support batch queries without a callback', done => {
          const id = '1234'
          const queries = [
            { query: 'INSERT INTO test.test (id) VALUES (?)', params: [id] },
            `UPDATE test.test SET test='test' WHERE id='${id}';`
          ]

          agent
            .use(traces => {
              expect(traces[0][0]).to.have.property('name', 'Batch: INSERT;UPDATE')
            })
            .then(done)
            .catch(done)

          try {
            client.batch(queries, { prepare: true })
          } catch (e) {
            // older versions require a callback
          }
        })

        it('should handle errors', done => {
          let error

          agent
            .use(traces => {
              expect(traces[0][0].meta).to.have.property('error', 'true')
              expect(traces[0][0].meta).to.have.property('sfx.error.kind', error.name)
              expect(traces[0][0].meta).to.have.property('sfx.error.message', error.message)
              expect(traces[0][0].meta).to.have.property('sfx.error.stack', error.stack)
            })
            .then(done)
            .catch(done)

          client.execute('INVALID;', err => {
            error = err
          })
        })

        it('should run the callback in the parent context', done => {
          if (process.env.DD_CONTEXT_PROPAGATION === 'false') return done()

          const scope = tracer.scope()
          const childOf = tracer.startSpan('test')

          scope.activate(childOf, () => {
            client.execute('SELECT now() FROM local;', () => {
              expect(tracer.scope().active()).to.equal(childOf)
              done()
            })
          })
        })

        it('should run the batch callback in the parent context', done => {
          if (process.env.DD_CONTEXT_PROPAGATION === 'false') return done()

          const scope = tracer.scope()
          const childOf = tracer.startSpan('test')

          scope.activate(childOf, () => {
            client.batch([`UPDATE test.test SET test='test' WHERE id='1234';`], () => {
              expect(tracer.scope().active()).to.equal(childOf)
              done()
            })
          })
        })

        it('should run event listeners in the correct scope', done => {
          if (process.env.DD_CONTEXT_PROPAGATION === 'false') return done()

          const emitter = client.stream('SELECT now() FROM local;')
          const span = tracer.startSpan('test')
          const scope = tracer.scope()

          scope.activate(span, () => {
            emitter.once('readable', (a, b, c) => {
              expect(scope.active()).to.equal(span)
              done()
            })
          })
        })
      })

      describe('with configuration', () => {
        let client

        before(() => {
          return agent.load(plugin, 'cassandra-driver', { service: 'custom' })
        })

        after(() => {
          return agent.close()
        })

        beforeEach(done => {
          cassandra = require(`../../versions/cassandra-driver@${version}`).get()

          client = new cassandra.Client({
            contactPoints: ['127.0.0.1'],
            localDataCenter: 'datacenter1',
            keyspace: 'system'
          })

          client.keyspace

          client.connect(done)
        })

        afterEach(done => {
          client.shutdown(done)
        })

        it('should be configured with the correct values', done => {
          agent.use(traces => {
            expect(traces[0][0]).to.have.property('service', 'test')
            done()
          })

          client.execute('SELECT now() FROM local;', err => err && done(err))
        })
      })

      // Promise support added in 3.2.0
      if (semver.intersects(version, '>=3.2.0')) {
        describe('with the promise API', () => {
          let client

          before(() => {
            return agent.load(plugin, 'cassandra-driver')
          })

          after(() => {
            return agent.close()
          })

          beforeEach(done => {
            cassandra = require(`../../versions/cassandra-driver@${version}`).get()

            client = new cassandra.Client({
              contactPoints: ['127.0.0.1'],
              localDataCenter: 'datacenter1',
              keyspace: 'system'
            })

            client.keyspace

            client.connect(done)
          })

          afterEach(done => {
            client.shutdown(done)
          })

          it('should do automatic instrumentation', done => {
            const query = 'SELECT now() FROM local;'

            agent
              .use(traces => {
                expect(traces[0][0]).to.have.property('service', 'test')
                expect(traces[0][0]).to.have.property('name', 'SELECT')
                expect(traces[0][0].meta).to.have.property('db.type', 'cassandra')
                expect(traces[0][0].meta).to.have.property('span.kind', 'client')
                expect(traces[0][0].meta).to.have.property('peer.ipv4', '127.0.0.1')
                expect(traces[0][0].meta).to.have.property('peer.port', '9042')
                expect(traces[0][0].meta).to.have.property('db.statement', query)
                expect(traces[0][0].meta).to.have.property('db.instance', 'system')
              })
              .then(done)
              .catch(done)

            client.execute(query)
              .catch(done)
          })

          it('should support batch queries', done => {
            const id = '1234'
            const queries = [
              { query: 'INSERT INTO test.test (id) VALUES (?)', params: [id] },
              `UPDATE test.test SET test='test' WHERE id='${id}';`
            ]

            agent
              .use(traces => {
                expect(traces[0][0]).to.have.property('name', 'Batch: INSERT;UPDATE')
              })
              .then(done)
              .catch(done)

            client.batch(queries, { prepare: true })
              .catch(done)
          })
        })
      }
    })
  })
})
